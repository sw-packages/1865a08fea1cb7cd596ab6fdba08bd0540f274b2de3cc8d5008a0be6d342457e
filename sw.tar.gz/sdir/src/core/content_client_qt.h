// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only
// Qt-Security score:critical reason:execute-external-code

#ifndef CONTENT_CLIENT_QT_H
#define CONTENT_CLIENT_QT_H

#include "qtwebenginecoreglobal_p.h"

#include "base/synchronization/lock.h"
#include "components/embedder_support/origin_trials/origin_trial_policy_impl.h"
#include "content/public/common/content_client.h"
#include "gpu/config/gpu_info.h"
#include "ui/base/layout.h"

#include <memory>
#include <optional>

namespace QtWebEngineCore {

class ContentClientQt : public content::ContentClient {
public:
#if QT_CONFIG(webengine_pepper_plugins)
    void AddPlugins(std::vector<content::ContentPluginInfo> *plugins) override;
#endif
    void AddContentDecryptionModules(std::vector<content::CdmInfo> *cdms,
                                     std::vector<media::CdmHostFilePath> *cdm_host_file_paths) override;
    void AddAdditionalSchemes(Schemes* schemes) override;

    std::string_view GetDataResource(int, ui::ResourceScaleFactor) override;
    base::RefCountedMemory* GetDataResourceBytes(int resource_id) override;
    gfx::Image &GetNativeImageNamed(int resource_id) override;
    std::u16string GetLocalizedString(int message_id) override;
    blink::OriginTrialPolicy *GetOriginTrialPolicy() override;
    void SetGpuInfo(const gpu::GPUInfo &gpu_info) override;

private:
    // Used to lock when |origin_trial_policy_| is initialized.
    base::Lock origin_trial_policy_lock_;
    std::unique_ptr<embedder_support::OriginTrialPolicyImpl> origin_trial_policy_;
    std::optional<gpu::GPUInfo> m_gpuInfo;
};

} // namespace QtWebEngineCore

#endif // CONTENT_CLIENT_QT_H
